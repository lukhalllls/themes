{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.master')

@section('title')
    @lang('server.config.sftp.header')
@endsection

@section('content-header')
    <h1>@lang('server.config.sftp.header')<small>@lang('server.config.sftp.header_sub')</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('index') }}">@lang('strings.home')</a></li>
        <li><a href="{{ route('server.index', $server->uuidShort) }}">{{ $server->name }}</a></li>
        <li>@lang('navigation.server.configuration')</li>
        <li class="active">@lang('navigation.server.sftp_settings')</li>
    </ol>
@endsection

@section('content')
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">@lang('Conexão Via SFTP')</h3>
            </div>
            <div class="box-body">
                <div class="form-group">
                    <label class="control-label">@lang('Conexão Para Android')</label>
                    <div>
                        <div> 
                       <label class="control-label">@lang('Servidor')</label>
                         <input type="text" class="form-control" readonly value="{{ $node->fqdn }}" />
                          </div>
                           <div>
                        	<label class="control-label">@lang('Porta')</label>
                         <input type="text" class="form-control" readonly value="{{ $node->daemonSFTP }}" />
                         </div>
                          </div>
                       
                     <div>
                          <label class="control-label">@lang('Conexão Para Filezila')</label>

                         <input type="text" class="form-control" readonly value="sftp://{{ $node->fqdn }}:{{ $node->daemonSFTP }}" /> 


                         </div>
 
                <div class="form-group">
                    <label for="password" class="control-label">@lang('Nome De Usuário Para Conexão')</label>
                    <div>
                        <input type="text" class="form-control" readonly value="{{ auth()->user()->username }}.{{ $server->uuidShort }}" />
                    </div>
              <label for="password" class="control-label">@lang('A Senha É A Mesma Do Seu Login Ao Painel!')</label>
              </div>
<div> 
<label class="control-label">@lang('Downloand Do Es File Explorer (Android)')</label>
 <a href="https://es-file-explorer.br.uptodown.com/android">DOWNLOAND</a>    

 </div>
  
<div>

<label class="control-label">@lang('Downloand Filezila (PC)')</label>

 <a href="https://filezilla-project.org/download.php?platform=win64">DOWNLOAND</a>



 </div>
    </div>
</div>
@endsection

@section('footer-scripts')
    @parent
    {!! Theme::js('js/frontend/server.socket.js') !!}
@endsect

