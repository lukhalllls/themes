<?php

namespace Pterodactyl\Models\Objects;

class DeploymentObject
{
    private bool $dedicated = false;

    private array $locations = [];

    private array $ports = [];
	
	private bool $cloud = false;
    
	private int $node = -1;

    public function isDedicated(): bool
    {
        return $this->dedicated;
    }

    public function setDedicated(bool $dedicated): self
    {
        $this->dedicated = $dedicated;

        return $this;
    }

    public function getLocations(): array
    {
        return $this->locations;
    }

    public function setLocations(array $locations): self
    {
        $this->locations = $locations;

        return $this;
    }

    public function getPorts(): array
    {
        return $this->ports;
    }

    public function setPorts(array $ports): self
    {
        $this->ports = $ports;

        return $this;
    }

public function getCloud(): bool
    {
        if($this->cloud) {
            return true;
        }
        return false;
    }

    /**
     * @return $this
     */
    public function setCloud(bool $cloud)
    {
        $this->cloud = $cloud;

        return $this;
    }
    /**
     * @return $this
     */
    public function setNode(int $node)
    {
        $this->node = $node;

        return $this;
    }

    public function getNode(): int
    {
        return $this->node;
    }
}
