$(document).ready(function()
{
	$('.main [href="?m=user_games"]').addClass('btn btn-primary btn-xs');
});