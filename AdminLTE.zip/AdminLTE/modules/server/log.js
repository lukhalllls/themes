$(document).ready(function()
{
    $('.main textarea[name="file_content"]').addClass('mb-2');
    $('.main input[name="save_file"]').addClass('btn-secondary');
    $('.main [href="?m=server"]').addClass('btn btn-sm btn-primary');
});
