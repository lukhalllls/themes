$(document).ready(function()
{
	$('.main').addClass('services');
	$('.main input[value="'+langConsts['OGP_LANG_remove_service']+'"]').removeClass('btn-primary').addClass('btn-danger');
});
