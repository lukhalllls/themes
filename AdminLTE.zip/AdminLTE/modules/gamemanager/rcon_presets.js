$(document).ready(function()
{
	$('.main [href^="?m=gamemanager&p=game_monitor&home_id="]').addClass('btn btn-sm btn-primary');
	$('[name="del_rcon_preset"]').removeClass('btn-primary').addClass('btn-danger');
});
