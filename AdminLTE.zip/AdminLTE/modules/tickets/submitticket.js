$(document).ready(function()
{
	$('#add_file_attachment').addClass('btn-secondary').prepend('<i class="fas fa-plus-circle mr-1"></i>');
	// $('#submit').addClass('mt-2');
});
