$(document).ready(function()
{
	$('.main input[name="remove"]').removeClass('btn-primary').addClass('btn-danger');
	$('.main input[name="show_all"]').removeClass('btn-primary').addClass('btn-warning float-right');
});