<?php
###############################################
# Site configuration
###############################################
$db_host="localhost";
$db_user="ogpuser";
$db_pass="BNyAHEKhPDrd";
$db_name="ogp_panel";
$table_prefix="ogp_";
$db_type="mysql";
?>