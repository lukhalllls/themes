About Times Square

	Times Square is a font made up of individual dots, much like those you would find on displays of stock prices, or like in the scrolling news display in New York's Times Square (hence the name). This version of the Time Square font also includes the character for the new Euro currency.

Contacting the Author

	You can email me at minow@henge.com. Or check out my web pages at http://www.henge.com/~minow/home.html.

	This font is provided free of charge, and you may use it any way you wish, including giving it to your friends. Just include this read me file with the font.

	I have tested this font fairly thoroughly, and have found no problems. However, as with all software, use this at your own risk.

1/3/99
